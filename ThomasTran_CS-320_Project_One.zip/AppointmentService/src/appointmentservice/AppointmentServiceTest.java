package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private AppointmentService service;
    private Appointment appointment;

    @BeforeEach
    public void setUp() {

        service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment");
    }

    @Test
    public void testAddAppointment() {

        service.addAppointment(appointment);

        assertEquals(
                appointment,
                service.getAppointment("12345"));
    }

    @Test
    public void testAddDuplicateAppointmentId() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment duplicate = new Appointment(
                "12345",
                futureDate,
                "Another appointment");

        service.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(duplicate);
        });
    }

    @Test
    public void testAddNullAppointment() {

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }

    @Test
    public void testDeleteAppointment() {

        service.addAppointment(appointment);

        service.deleteAppointment("12345");

        assertNull(service.getAppointment("12345"));
    }

    @Test
    public void testDeleteAppointmentNotFound() {

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("99999");
        });
    }
}