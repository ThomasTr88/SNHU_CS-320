package appointmentservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate;
    private Appointment appointment;

    @BeforeEach
    public void setUp() {
        futureDate = new Date(System.currentTimeMillis() + 86400000);

        appointment = new Appointment(
                "12345",
                futureDate,
                "Doctor appointment");
    }

    @Test
    public void testAppointmentCreation() {
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor appointment", appointment.getDescription());
    }

    @Test
    public void testAppointmentIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentIdCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("", futureDate, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentIdCannotBeLongerThanTen() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Doctor appointment");
        });
    }

    @Test
    public void testAppointmentDateCannotBeInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Doctor appointment");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }

    @Test
    public void testDescriptionCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, "");
        });
    }

    @Test
    public void testDescriptionCannotBeLongerThanFifty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "12345",
                    futureDate,
                    "This description is longer than fifty characters and should fail");
        });
    }

    @Test
    public void testSetAppointmentDate() {
        Date newFutureDate = new Date(System.currentTimeMillis() + 172800000);

        appointment.setAppointmentDate(newFutureDate);

        assertEquals(newFutureDate, appointment.getAppointmentDate());
    }

    @Test
    public void testSetAppointmentDateCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(null);
        });
    }

    @Test
    public void testSetAppointmentDateCannotBeInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(pastDate);
        });
    }

    @Test
    public void testSetDescription() {
        appointment.setDescription("Dentist appointment");

        assertEquals("Dentist appointment", appointment.getDescription());
    }

    @Test
    public void testSetDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    @Test
    public void testSetDescriptionCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("");
        });
    }

    @Test
    public void testSetDescriptionCannotBeLongerThanFifty() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(
                    "This description is longer than fifty characters and should fail");
        });
    }

    @Test
    public void testBoundaryValues() {
        assertDoesNotThrow(() -> {
            new Appointment(
                    "1234567890",
                    futureDate,
                    "12345678901234567890123456789012345678901234567890");
        });
    }
}