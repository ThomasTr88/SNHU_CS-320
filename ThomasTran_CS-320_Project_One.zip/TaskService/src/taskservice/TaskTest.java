package taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskTest {

    private Task task;

    @BeforeEach
    public void setUp() {
        task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment");
    }

    @Test
    public void testTaskCreation() {
        assertEquals("12345", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Complete Java assignment", task.getDescription());
    }

    @Test
    public void testTaskIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Homework", "Complete Java assignment");
        });
    }

    @Test
    public void testTaskIdCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("", "Homework", "Complete Java assignment");
        });
    }

    @Test
    public void testTaskIdCannotBeLongerThanTen() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Homework", "Complete Java assignment");
        });
    }

    @Test
    public void testNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", null, "Complete Java assignment");
        });
    }

    @Test
    public void testNameCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "", "Complete Java assignment");
        });
    }

    @Test
    public void testNameCannotBeLongerThanTwenty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "ThisNameIsWayTooLong123", "Complete Java assignment");
        });
    }

    @Test
    public void testDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", null);
        });
    }

    @Test
    public void testDescriptionCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345", "Homework", "");
        });
    }

    @Test
    public void testDescriptionCannotBeLongerThanFifty() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345",
                    "Homework",
                    "This description is longer than fifty characters and should fail");
        });
    }

    @Test
    public void testSetName() {
        task.setName("Project");
        assertEquals("Project", task.getName());
    }

    @Test
    public void testSetNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
    }

    @Test
    public void testSetNameCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("");
        });
    }

    @Test
    public void testSetNameCannotBeLongerThanTwenty() {
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("ThisNameIsWayTooLong123");
        });
    }

    @Test
    public void testSetDescription() {
        task.setDescription("Study for quiz");
        assertEquals("Study for quiz", task.getDescription());
    }

    @Test
    public void testSetDescriptionCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
    }

    @Test
    public void testSetDescriptionCannotBeEmpty() {
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("");
        });
    }

    @Test
    public void testSetDescriptionCannotBeLongerThanFifty() {
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(
                    "This description is longer than fifty characters and should fail");
        });
    }

    @Test
    public void testBoundaryValues() {
        assertDoesNotThrow(() -> {
            new Task(
                    "1234567890",
                    "12345678901234567890",
                    "12345678901234567890123456789012345678901234567890");
        });
    }
}