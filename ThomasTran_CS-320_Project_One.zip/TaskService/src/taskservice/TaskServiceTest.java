package taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;
    private Task task;

    @BeforeEach
    public void setUp() {

        service = new TaskService();

        task = new Task(
                "12345",
                "Homework",
                "Complete Java assignment");
    }

    @Test
    public void testAddTask() {

        service.addTask(task);

        assertEquals(task, service.getTask("12345"));
    }

    @Test
    public void testAddDuplicateTaskId() {

        Task duplicate = new Task(
                "12345",
                "Project",
                "Different task");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(duplicate);
        });
    }

    @Test
    public void testAddNullTask() {

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(null);
        });
    }

    @Test
    public void testDeleteTask() {

        service.addTask(task);

        service.deleteTask("12345");

        assertNull(service.getTask("12345"));
    }

    @Test
    public void testDeleteTaskNotFound() {

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("99999");
        });
    }

    @Test
    public void testUpdateName() {

        service.addTask(task);

        service.updateName("12345", "Project");

        assertEquals(
                "Project",
                service.getTask("12345").getName());
    }

    @Test
    public void testUpdateDescription() {

        service.addTask(task);

        service.updateDescription(
                "12345",
                "Study for final exam");

        assertEquals(
                "Study for final exam",
                service.getTask("12345").getDescription());
    }

    @Test
    public void testUpdateNameNotFound() {

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("99999", "Project");
        });
    }

    @Test
    public void testUpdateDescriptionNotFound() {

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription(
                    "99999",
                    "Study for final exam");
        });
    }
    
    @Test
    public void testUpdateNameInvalidValue() {

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("12345", "");
        });
    }

    @Test
    public void testUpdateDescriptionInvalidValue() {

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("12345", "");
        });
    }
}